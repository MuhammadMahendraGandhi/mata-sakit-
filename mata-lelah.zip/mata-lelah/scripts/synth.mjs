// Sintesis musik latar + SFX halus -> public/musik.wav, public/sfx/*.wav
// Jalankan: node scripts/synth.mjs  (sudah dijalankan; file WAV ikut di zip)
import fs from 'node:fs';

const SR = 44100;
fs.mkdirSync('public/sfx', {recursive: true});

const wav = (samples, file) => {
  const n = samples.length;
  const buf = Buffer.alloc(44 + n * 2);
  buf.write('RIFF', 0); buf.writeUInt32LE(36 + n * 2, 4); buf.write('WAVE', 8);
  buf.write('fmt ', 12); buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20);
  buf.writeUInt16LE(1, 22); buf.writeUInt32LE(SR, 24); buf.writeUInt32LE(SR * 2, 28);
  buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34); buf.write('data', 36);
  buf.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) {
    const v = Math.max(-1, Math.min(1, samples[i]));
    buf.writeInt16LE(Math.round(v * 32767), 44 + i * 2);
  }
  fs.writeFileSync(file, buf);
};
const mk = (sec) => new Float32Array(Math.ceil(sec * SR));
const TAU = Math.PI * 2;
let seed = 12345;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;

// nada lembut ala piano/kalimba: sinus + harmonik, serangan cepat, peluruhan eksponensial
const note = (buf, t0, freq, dur, vol) => {
  const s0 = Math.floor(t0 * SR);
  const len = Math.floor(dur * SR);
  for (let i = 0; i < len && s0 + i < buf.length; i++) {
    const t = i / SR;
    const env = Math.min(1, t / 0.008) * Math.exp(-t * 3.2);
    const v =
      Math.sin(TAU * freq * t) +
      0.35 * Math.sin(TAU * freq * 2 * t) * Math.exp(-t * 5) +
      0.12 * Math.sin(TAU * freq * 3 * t) * Math.exp(-t * 8);
    buf[s0 + i] += v * env * vol;
  }
};
const hz = (m) => 440 * Math.pow(2, (m - 69) / 12);

// ---------- MUSIK: C mayor pentatonik, progresi C - Am - F - G, arpeggio pelan ----------
const musicLen = 70;
const music = mk(musicLen);
const chords = [
  [48, 55, 60, 64], // C
  [45, 52, 57, 60], // Am
  [41, 48, 53, 57], // F
  [43, 50, 55, 59], // G
];
const beat = 0.6;
for (let bar = 0; bar * beat * 4 < musicLen; bar++) {
  const ch = chords[bar % 4];
  const t0 = bar * beat * 4;
  note(music, t0, hz(ch[0] - 12), 2.4, 0.16); // bas lembut
  for (let k = 0; k < 8; k++) {
    const m = ch[(k % 4)] + 12 + (k === 5 ? 2 : 0);
    note(music, t0 + k * beat * 0.5, hz(m), 1.4, 0.07);
  }
}
// fade in/out
for (let i = 0; i < music.length; i++) {
  const t = i / SR;
  music[i] *= Math.min(1, t / 2) * Math.min(1, (musicLen - t) / 3);
}
wav(music, 'public/musik.wav');

// ---------- SFX ----------
const sfx = (name, sec, fn) => {
  const b = mk(sec);
  for (let i = 0; i < b.length; i++) b[i] = fn(i / SR);
  wav(b, `public/sfx/${name}.wav`);
};
const lp = () => { let y = 0; return (x, a) => (y += a * (x - y)); };

sfx('bonk', 0.35, (t) => Math.sin(TAU * (260 - 120 * t) * t) * Math.exp(-t * 14) * 0.5);
sfx('plop', 0.3, (t) => Math.sin(TAU * (500 * Math.exp(-t * 9)) * t * 1.2) * Math.exp(-t * 16) * 0.5);
sfx('pip', 0.4, (t) => {
  const g = t < 0.1 ? 1 : t > 0.18 && t < 0.28 ? 1 : 0;
  return Math.sin(TAU * 1500 * t) * g * Math.exp(-((t % 0.18)) * 20) * 0.28;
});
sfx('tung', 0.8, (t) => (Math.sin(TAU * 392 * t) + 0.4 * Math.sin(TAU * 784 * t)) * Math.exp(-t * 6) * 0.35);
sfx('gigit', 0.25, (t) => rnd() * Math.exp(-t * 28) * 0.4 * (t < 0.03 ? 1 : 0.5));
sfx('desir', 0.9, (t) => { return rnd() * Math.sin(Math.PI * Math.min(1, t / 0.9)) * 0.12; });
sfx('tawa', 1.2, (t) => {
  const pulse = Math.max(0, Math.sin(TAU * 5 * t)) * Math.exp(-t * 2);
  return Math.sin(TAU * (300 + 60 * Math.sin(TAU * 5 * t)) * t) * pulse * 0.18;
});
sfx('burung', 1.6, (t) => {
  const chirp = (t0) => {
    const d = t - t0;
    if (d < 0 || d > 0.14) return 0;
    return Math.sin(TAU * (2600 + 900 * Math.sin(d * 60)) * d) * Math.sin((Math.PI * d) / 0.14) * 0.14;
  };
  return chirp(0.1) + chirp(0.3) + chirp(0.48) + chirp(1.0) + chirp(1.18);
});
sfx('sentuh', 0.2, (t) => rnd() * Math.exp(-t * 35) * 0.18);
sfx('seret', 0.7, (t) => { const f = lp(); return f(rnd(), 0.15) * Math.sin(Math.PI * Math.min(1, t / 0.7)) * 0.5; });
sfx('hujan', 4, () => { const f = lp(); return f(rnd(), 0.6) * 0.1; });
sfx('petir', 1.6, (t) => { const f = lp(); return f(rnd(), 0.05) * Math.exp(-t * 3) * 1.2; });
sfx('jangkrik', 3, (t) => (Math.sin(TAU * 4200 * t) * (Math.sin(TAU * 14 * t) > 0.3 ? 1 : 0) * 0.04));

// ---------- SFX tambahan untuk cerita mata lelah ----------
sfx('ketik', 1.4, (t) => {
  const hits = [0.05, 0.19, 0.31, 0.5, 0.62, 0.8, 0.93, 1.1, 1.24];
  let v = 0;
  for (const h of hits) { const d = t - h; if (d >= 0 && d < 0.04) v += rnd() * Math.exp(-d * 120) * 0.22; }
  return v;
});
sfx('tik', 3, (t) => {
  const d = t % 0.5;
  return d < 0.05 ? Math.sin(TAU * (d < 0.02 ? 1800 : 1200) * d) * Math.exp(-d * 90) * 0.3 : 0;
});
sfx('kedip', 0.18, (t) => rnd() * Math.exp(-t * 60) * 0.14 + Math.sin(TAU * 700 * t) * Math.exp(-t * 50) * 0.12);
sfx('ting', 1.1, (t) => (Math.sin(TAU * 1318 * t) + 0.4 * Math.sin(TAU * 2637 * t)) * Math.exp(-t * 4.5) * 0.28);
sfx('zing', 0.9, (t) => Math.sin(TAU * (900 + 1400 * t) * t) * Math.sin(Math.PI * Math.min(1, t / 0.9)) * 0.14);
sfx('swoosh', 0.7, (t) => { const f = lp(); return f(rnd(), 0.05 + 0.5 * (t / 0.7)) * Math.sin(Math.PI * Math.min(1, t / 0.7)) * 0.7; });
sfx('sparkle', 1, (t) => {
  let v = 0;
  [0, 0.09, 0.18, 0.27, 0.36].forEach((h, i) => { const d = t - h; if (d >= 0) v += Math.sin(TAU * (1568 * Math.pow(1.26, i)) * d) * Math.exp(-d * 9) * 0.12; });
  return v;
});
sfx('retak', 0.6, (t) => {
  const g = Math.max(0, Math.sin(t * 90)) > 0.9 ? 1 : 0.15;
  return rnd() * Math.exp(-t * 7) * g * 0.35;
});
console.log('musik + sfx selesai');
