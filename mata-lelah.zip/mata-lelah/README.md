# Mata Lelah di Optik — animasi Remotion 9:16

Kartun 2D vektor datar (SVG), 1080x1920, 30 fps, tentang kenapa mata sakit setelah lama menatap layar dan cara menanganinya.
Narasi, musik, dan SFX sudah masuk komposisi, jadi satu perintah render menghasilkan MP4 bersuara.

## Pakai
```bash
npm install
npm run start     # Remotion Studio (pratinjau/penyetelan)
npm run render    # hasil: out/mata-lelah.mp4
npm run tsc       # cek tipe
```

## Cerita
Satu dunia penampang: langit, optik di permukaan (bagan huruf, rak bingkai, jam, jendela), dan bawah tanah.
Dani (pekerja muda) bekerja di meja laptop. Mimi (karakter mata) menunjukkan penyebabnya.
- Air tanah di bawah = lapisan air mata. Turun saat jarang berkedip, retak tergambar bertahap saat mata kering, naik lagi saat berkedip sengaja.
- Langit: siang, senja, malam saat lama menatap, lalu subuh dan pagi saat solusi. Akar tumbuh di bawah tanah selama bagian solusi.
- Kartu info (kedipan per menit, aturan 20, 6 meter, sepanjang lengan, di bawah mata) ada di `src/components/Hud.tsx`.

## Yang bisa disetel (semua di `public/timing.json`)
- `audioDurationSec`: durasi narasi. Durasi video = ini + `tailSec` (1 detik). **Ganti angka ini bila mengganti narasi.mp3**
  (cek dengan `ffprobe narasi.mp3`). Sekarang 68.362449 detik, jadi video 2081 frame.
- `scenes[]`: satu entri = satu kalimat SRT = satu adegan (`start`, `end`, `text`). `subtitle` adalah teks tampil
  yang sudah dirapikan dari typo transkrip; hapus field itu bila ingin teks SRT apa adanya.
  Nama `scene` (perih, lama, jarang, ...) dipakai kode koreografi, jangan diubah. Ubah `start`/`end` untuk menggeser adegan.
- `sfx[]`: `scene` (id adegan), `offset` (detik dari awal adegan), `file` (nama di `public/sfx`), `volume`.
- `sky[]`: keyframe langit (warna, bintang, matahari, awan) per detik.

Koreografi (kamera, Dani, Mimi, laptop, air tanah) ada di `src/lib/story.ts`, dengan waktu relatif terhadap adegan
(`T('aturan', 1.5)` = 1,5 detik setelah adegan "aturan" mulai), jadi ikut bergeser bila timing.json diubah.

## Audio
- `public/narasi.mp3`: dipakai apa adanya.
- `public/musik.wav` dan `public/sfx/*.wav`: disintesis oleh `scripts/synth.mjs` (`node scripts/synth.mjs` untuk membuat ulang).
  Volume musik diatur di `src/components/AudioMix.tsx`.

## Catatan
- `naskah.txt` dan `screenshot/gaya-*.png` tidak ikut terlampir; cerita diambil dari SRT dan gaya dari deskripsi
  (outline hitam tebal, warna flat, bayangan satu tingkat). Palet ada di `src/lib/palette.ts`.
- SRT transkrip berhenti di "Istirahatkan matamu"; audio berdurasi 68,36 detik, jadi subtitle terakhir ditulis "Istirahatkan matamu, ya."
  Jika di audio ada kalimat setelahnya, tambahkan adegan di `timing.json`.
- Project belum pernah dirender di lingkungan pembuatannya, jadi cek hasil visual lewat `npm run start` dulu.
