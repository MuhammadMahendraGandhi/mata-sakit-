import React from 'react';
import {C, OUT_S, OUT_W} from '../lib/palette';
import {blinkRate, E, hud, T} from '../lib/story';
import {lerp} from '../lib/timing';

const font = "'Trebuchet MS', Verdana, 'DejaVu Sans', sans-serif";

const Txt: React.FC<{x: number; y: number; size: number; fill?: string; anchor?: 'start' | 'middle' | 'end'; children: React.ReactNode}> = ({
  x, y, size, fill = C.outline, anchor = 'middle', children,
}) => (
  <text x={x} y={y} textAnchor={anchor} fontFamily={font} fontWeight={800} fontSize={size} fill={fill}>{children}</text>
);

const Eye: React.FC<{x: number; y: number}> = ({x, y}) => (
  <g transform={`translate(${x} ${y})`}>
    <ellipse rx={44} ry={32} fill="#fffdf8" stroke={C.outline} strokeWidth={OUT_S + 1} />
    <circle r={17} fill={C.iris} stroke={C.outline} strokeWidth={OUT_S} />
    <circle r={7} fill={C.outline} />
  </g>
);

export const Hud: React.FC<{t: number}> = ({t}) => {
  const h = hud(t);
  if (!h.kind || h.a <= 0.01) return null;
  const p = h.p;

  let body: React.ReactNode = null;
  if (h.kind === 'kedip') {
    const sengaja = t >= T('kedip') - 0.1;
    const n = blinkRate(t);
    body = (
      <>
        <Eye x={110} y={150} />
        <Txt x={560} y={66} size={36} anchor="middle">{sengaja ? 'Berkedip dengan sengaja' : 'Kedipan per menit'}</Txt>
        <Txt x={420} y={190} size={120} fill={sengaja ? C.grassDark : C.vein}>{n}</Txt>
        <Txt x={640} y={190} size={36} anchor="start">kali / menit</Txt>
        <rect x={230} y={218} width={640} height={22} rx={11} fill="#e9dfcf" stroke={C.outline} strokeWidth={OUT_S} />
        <rect x={230} y={218} width={(640 * n) / 15} height={22} rx={11} fill={sengaja ? C.water : C.vein} stroke={C.outline} strokeWidth={OUT_S} />
      </>
    );
  } else if (h.kind === 'jam') {
    const jam = Math.round(lerp(0, 12, p));
    body = (
      <>
        <Txt x={450} y={80} size={36}>Lama menatap layar</Txt>
        <Txt x={360} y={200} size={120} fill={C.roof}>{jam}</Txt>
        <Txt x={520} y={200} size={44} anchor="start">jam nonstop</Txt>
      </>
    );
  } else if (h.kind === 'aturan') {
    const r = 92;
    const circ = 2 * Math.PI * r;
    body = (
      <>
        <g transform="translate(180 150)">
          <circle r={r} fill="#fffdf5" stroke={C.outline} strokeWidth={OUT_W} />
          <circle r={r - 2} fill="none" stroke={C.water} strokeWidth={16} strokeLinecap="round"
            strokeDasharray={circ} strokeDashoffset={circ * (1 - Math.min(1, p * 1.25))} transform="rotate(-90)" />
          <Txt x={0} y={30} size={84}>20</Txt>
        </g>
        <Txt x={640} y={110} size={46}>Aturan 20</Txt>
        <Txt x={640} y={176} size={36}>setiap 20 menit</Txt>
      </>
    );
  } else if (h.kind === 'enam') {
    const left = Math.max(0, Math.ceil(20 - p * 20));
    body = (
      <>
        <Eye x={110} y={140} />
        <line x1={170} y1={140} x2={640} y2={140} stroke={C.outline} strokeWidth={6} strokeDasharray="14 12" strokeLinecap="round" />
        <path d="M640 140 l-26 -16 v32z" fill={C.outline} />
        <g transform="translate(730 150)">
          <rect x={-8} y={-30} width={16} height={60} fill={C.wood} stroke={C.outline} strokeWidth={OUT_S} />
          <circle cy={-52} r={40} fill={C.grass} stroke={C.outline} strokeWidth={OUT_S + 1} />
        </g>
        <Txt x={405} y={110} size={54}>6 meter</Txt>
        <Txt x={450} y={235} size={40}>{`selama ${left} detik`}</Txt>
      </>
    );
  } else if (h.kind === 'lengan') {
    body = (
      <>
        <g transform="translate(120 140)">
          <circle r={34} fill={C.skin} stroke={C.outline} strokeWidth={OUT_S + 1} />
          <path d="M-14 -4 L-6 -4 M6 -4 L14 -4" stroke={C.outline} strokeWidth={5} strokeLinecap="round" />
        </g>
        <rect x={680} y={92} width={110} height={96} rx={8} fill={C.laptop} stroke={C.outline} strokeWidth={OUT_S + 1} />
        <path d="M170 140 L670 140 M170 126 L170 154 M670 126 L670 154" stroke={C.outline} strokeWidth={6} strokeLinecap="round" />
        <Txt x={420} y={110} size={46}>sepanjang lengan</Txt>
        <Txt x={420} y={216} size={36}>± 50-70 cm dari mata</Txt>
      </>
    );
  } else if (h.kind === 'posisi') {
    body = (
      <>
        <line x1={90} y1={90} x2={810} y2={90} stroke={C.outline} strokeWidth={5} strokeDasharray="16 12" />
        <Txt x={450} y={72} size={32}>setinggi mata</Txt>
        <rect x={330} y={130} width={240} height={110} rx={10} fill="#cfeeff" stroke={C.outline} strokeWidth={OUT_W} />
        <path d="M150 100 L150 190 M150 190 l-18 -22 M150 190 l18 -22" stroke={C.vein} strokeWidth={9} strokeLinecap="round" fill="none" />
        <Txt x={700} y={196} size={36}>sedikit di bawah</Txt>
        <Txt x={700} y={240} size={36}>mata</Txt>
      </>
    );
  }

  return (
    <div
      style={{
        position: 'absolute',
        left: 90,
        top: 120,
        width: 900,
        height: 300,
        opacity: h.a,
        transform: `translateY(${(1 - h.a) * -24}px)`,
        pointerEvents: 'none',
      }}
    >
      <svg width={900} height={300} viewBox="0 0 900 300">
        <rect x={6} y={6} width={888} height={288} rx={34} fill="rgba(255,253,245,0.94)" stroke={C.outline} strokeWidth={OUT_W} />
        <g transform="translate(0 0)">{body}</g>
      </svg>
    </div>
  );
};
