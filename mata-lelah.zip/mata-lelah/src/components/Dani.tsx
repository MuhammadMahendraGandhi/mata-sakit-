import React from 'react';
import {C, OUT_S, OUT_W} from '../lib/palette';
import {ease, lerp} from '../lib/timing';
import type {Expression} from '../lib/types';
import type {DPose} from '../lib/story';

const clamp01 = (x: number) => Math.min(1, Math.max(0, x));
const SH_Y = -252; // bahu (lokal, sebelum rotasi badan)
const SH_X = 48;

const armLen = (a: number): number => lerp(140, 84, ease(clamp01((Math.abs(a) - 105) / 55)));

/** Posisi tangan kanan (lokal, sebelum rotasi badan). */
export const daniHand = (a: number): {x: number; y: number} => {
  const L = armLen(a);
  const r = (a * Math.PI) / 180;
  return {x: SH_X + -Math.sin(r) * L, y: SH_Y + Math.cos(r) * L};
};

const Arm: React.FC<{sx: number; angle: number}> = ({sx, angle}) => {
  const L = armLen(angle);
  const bend = angle < 0 ? -15 : 15;
  const d = `M0 0 Q${bend} ${L * 0.5} 0 ${L}`;
  return (
    <g transform={`translate(${sx} ${SH_Y}) rotate(${angle})`}>
      <path d={d} stroke={C.outline} strokeWidth={32} strokeLinecap="round" fill="none" />
      <path d={d} stroke={C.skin} strokeWidth={20} strokeLinecap="round" fill="none" />
      <path d="M0 0 L0 46" stroke={C.outline} strokeWidth={44} strokeLinecap="round" />
      <path d="M0 0 L0 46" stroke={C.tee} strokeWidth={34} strokeLinecap="round" />
      <circle cx={0} cy={L} r={14} fill={C.skin} stroke={C.outline} strokeWidth={OUT_S} />
    </g>
  );
};

const Face: React.FC<{expr: Expression; mouth: number; blink: number}> = ({expr, mouth, blink}) => {
  const lw = {stroke: C.outline, strokeWidth: 6, strokeLinecap: 'round' as const, fill: 'none'};
  const closed = blink > 0.5;
  const eyes = closed ? (
    expr === 'senang' ? (
      <>
        <path d="M-36 4 Q-24 14 -12 4" {...lw} />
        <path d="M12 4 Q24 14 36 4" {...lw} />
      </>
    ) : (
      <>
        <path d="M-36 4 L-12 4" {...lw} />
        <path d="M12 4 L36 4" {...lw} />
      </>
    )
  ) : expr === 'senang' ? (
    <>
      <path d="M-36 6 Q-24 -8 -12 6" {...lw} />
      <path d="M12 6 Q24 -8 36 6" {...lw} />
    </>
  ) : expr === 'sedih' ? (
    <>
      <path d="M-36 8 L-12 2" {...lw} />
      <path d="M12 2 L36 8" {...lw} />
    </>
  ) : expr === 'kaget' ? (
    <>
      <path d="M-24 -8 L-24 12" {...lw} strokeWidth={8} />
      <path d="M24 -8 L24 12" {...lw} strokeWidth={8} />
    </>
  ) : (
    <>
      <path d="M-36 4 L-12 4" {...lw} />
      <path d="M12 4 L36 4" {...lw} />
    </>
  );
  const brows =
    expr === 'sedih' ? ['M-40 -10 L-12 -20', 'M12 -20 L40 -10']
    : expr === 'kaget' ? ['M-38 -26 Q-24 -36 -10 -26', 'M10 -26 Q24 -36 38 -26']
    : expr === 'tekad' ? ['M-40 -22 L-10 -10', 'M10 -10 L40 -22']
    : ['M-38 -18 Q-24 -26 -10 -18', 'M10 -18 Q24 -26 38 -18'];
  const my = 34;
  const m = mouth;
  const mouthShape =
    m > 0.15 ? <ellipse cx={0} cy={my + 4} rx={11 + m * 5} ry={4 + m * 12} fill={C.outline} />
    : expr === 'sedih' ? <path d={`M-13 ${my + 5} Q0 ${my - 4} 13 ${my + 5}`} {...lw} />
    : expr === 'senang' ? <path d={`M-15 ${my - 1} Q0 ${my + 12} 15 ${my - 1}`} {...lw} />
    : <path d={`M-11 ${my + 2} L11 ${my + 2}`} {...lw} />;
  return (
    <g>
      {brows.map((p, i) => <path key={i} d={p} stroke={C.hairBlack} strokeWidth={9} strokeLinecap="round" fill="none" />)}
      {eyes}
      {mouthShape}
    </g>
  );
};

export const Dani: React.FC<{pose: DPose; blink: number; x: number; floor: number}> = ({pose, blink, x, floor}) => {
  const hp = daniHand(pose.armR);
  return (
    <g transform={`translate(${x} ${floor})`}>
      <ellipse cx={30} cy={4} rx={110} ry={10} fill="#000" opacity={0.16} />
      {/* kaki (duduk): paha ke depan, betis ke bawah, sepatu */}
      <path d="M0 -118 L88 -122" stroke={C.outline} strokeWidth={62} strokeLinecap="round" />
      <path d="M0 -118 L88 -122" stroke={C.jeans} strokeWidth={50} strokeLinecap="round" />
      <path d="M88 -122 L90 -30" stroke={C.outline} strokeWidth={56} strokeLinecap="round" />
      <path d="M88 -122 L90 -30" stroke={C.jeans} strokeWidth={44} strokeLinecap="round" />
      <path d="M40 -138 L88 -140" stroke={C.jeansShade} strokeWidth={10} strokeLinecap="round" opacity={0.6} />
      <ellipse cx={112} cy={-16} rx={42} ry={18} fill={C.shoe} stroke={C.outline} strokeWidth={OUT_S + 1} />
      <path d="M78 -16 L146 -16" stroke={C.outline} strokeWidth={3} />
      {/* badan (condong ke layar) */}
      <g transform={`rotate(${pose.lean} 0 -120)`}>
        <Arm sx={-SH_X} angle={pose.armL} />
        <path d="M-52 -262 Q0 -280 52 -262 L56 -118 Q0 -106 -56 -118Z" fill={C.tee} stroke={C.outline} strokeWidth={OUT_W} strokeLinejoin="round" />
        <path d="M18 -270 L52 -262 L56 -118 Q36 -112 18 -112Z" fill={C.teeShade} opacity={0.85} />
        <path d="M-20 -270 Q0 -250 20 -270" stroke={C.outline} strokeWidth={OUT_S} fill="none" strokeLinecap="round" />
        <rect x={-16} y={-290} width={32} height={26} rx={8} fill={C.skin} stroke={C.outline} strokeWidth={OUT_S} />
        {/* kepala */}
        <g transform={`translate(${pose.neck} -350) rotate(${pose.tilt})`}>
          <circle cx={-60} cy={4} r={13} fill={C.skin} stroke={C.outline} strokeWidth={OUT_S} />
          <circle cx={60} cy={4} r={13} fill={C.skin} stroke={C.outline} strokeWidth={OUT_S} />
          <ellipse cx={0} cy={0} rx={60} ry={64} fill={C.skin} stroke={C.outline} strokeWidth={OUT_W} />
          <path d="M26 -54 Q62 -26 52 26 Q34 60 0 64 Q46 34 26 -54Z" fill={C.skinShade} opacity={0.5} />
          {/* rambut hitam pendek */}
          <path d="M-62 -4 Q-70 -52 -34 -68 Q4 -84 40 -64 Q64 -50 62 -4 Q58 -34 38 -44 Q10 -34 -14 -46 Q-44 -34 -52 -2 Q-56 4 -62 -4Z"
            fill={C.hairBlack} stroke={C.outline} strokeWidth={OUT_S + 1} strokeLinejoin="round" />
          <ellipse cx={0} cy={14} rx={7} ry={6} fill={C.skinShade} stroke={C.outline} strokeWidth={OUT_S - 1} />
          <g transform="translate(0 -4)"><Face expr={pose.expr} mouth={pose.mouth} blink={blink} /></g>
        </g>
        <Arm sx={SH_X} angle={pose.armR} />
        {pose.phone > 0.5 && (
          <g transform={`translate(${hp.x} ${hp.y}) rotate(${-8 + pose.armR * 0.1})`}>
            <rect x={-18} y={-44} width={36} height={64} rx={7} fill="#1a1d24" stroke={C.outline} strokeWidth={OUT_S} />
            <rect x={-13} y={-38} width={26} height={50} rx={3} fill={C.screenGlow} />
            <path d="M-8 -26 L8 -26 M-8 -16 L8 -16 M-8 -6 L4 -6" stroke={C.laptopShade} strokeWidth={3} strokeLinecap="round" />
          </g>
        )}
      </g>
    </g>
  );
};
