import React from 'react';
import {C, OUT_S} from '../lib/palette';
import {skyAt, WORLD} from '../lib/story';
import {lerp} from '../lib/timing';
import {mix} from '../lib/color';

const hash = (n: number): number => {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};

const L = WORLD.left;
const R = WORLD.right;
const W = R - L;
const SY = WORLD.surfaceY;

const Cloud: React.FC<{x: number; y: number; s: number; fill: string}> = ({x, y, s, fill}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <path
      d="M-120 0 Q-150 -2 -148 -30 Q-146 -58 -112 -54 Q-104 -92 -58 -88 Q-30 -118 12 -92 Q56 -108 82 -72 Q132 -76 136 -34 Q150 -4 112 0Z"
      fill={fill} stroke={C.outline} strokeWidth={OUT_S + 2} strokeLinejoin="round"
    />
  </g>
);

export const Sky: React.FC<{t: number}> = ({t}) => {
  const s = skyAt(t);
  const cloudFill = mix('#ffffff', '#9aa6b4', Math.min(1, s.rain * 1.1));
  const sunY = lerp(SY + 40, 360, s.sun);
  const sunCol = mix('#ffb25a', '#ffe66b', s.sun);
  const drops = 320;
  return (
    <g>
      <defs>
        <linearGradient id="skyG" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={s.top} />
          <stop offset="1" stopColor={s.bottom} />
        </linearGradient>
      </defs>
      <rect x={L} y={WORLD.top} width={W} height={SY - WORLD.top + 4} fill="url(#skyG)" />
      {/* bintang & bulan (malam menjelang subuh) */}
      {s.stars > 0.01 && (
        <g opacity={s.stars}>
          {Array.from({length: 70}, (_, i) => (
            <circle
              key={i}
              cx={L + hash(i) * W}
              cy={-400 + hash(i + 99) * 1500}
              r={2.5 + hash(i + 7) * 3 + Math.sin(t * 3 + i) * 0.8}
              fill="#fff6c8"
            />
          ))}
          <circle cx={430} cy={380} r={70} fill="#fff2b8" stroke={C.outline} strokeWidth={OUT_S + 1} />
          <circle cx={456} cy={362} r={62} fill={s.top} />
        </g>
      )}
      {/* matahari */}
      {s.sun > 0.01 && (
        <g transform={`translate(1100 ${sunY})`}>
          <circle r={118} fill={sunCol} opacity={0.28} />
          <circle r={84} fill={sunCol} stroke={C.outline} strokeWidth={OUT_S + 1} />
          {Array.from({length: 12}, (_, i) => (
            <path
              key={i}
              d="M0 -108 L0 -140"
              stroke={C.outline}
              strokeWidth={OUT_S + 1}
              strokeLinecap="round"
              transform={`rotate(${i * 30 + t * 6})`}
            />
          ))}
        </g>
      )}
      {/* awan */}
      {[0, 1, 2, 3, 4, 5].map((i) => {
        const x = L + ((hash(i + 3) * W + t * (8 + i * 2)) % (W + 400)) - 100;
        const vis = i < 2 ? 1 : s.cloud;
        return (
          <g key={i} opacity={Math.min(1, vis * 1.2)}>
            <Cloud x={x} y={250 + hash(i + 11) * 520} s={0.9 + hash(i + 21) * 0.9} fill={cloudFill} />
          </g>
        );
      })}
      {/* hujan */}
      {s.rain > 0.02 && (
        <g stroke="#e6f3ff" strokeWidth={3.2} strokeLinecap="round" opacity={0.75 * Math.min(1, s.rain * 1.5)}>
          {Array.from({length: drops}, (_, i) => {
            if (hash(i + 500) > s.rain) return null;
            const sp = 900 + hash(i + 1) * 500;
            const x0 = L + hash(i + 2) * W;
            const y = 150 + ((hash(i + 3) * 1200 + t * sp) % 1200);
            return <line key={i} x1={x0 - y * 0.12} y1={y} x2={x0 - y * 0.12 - 9} y2={y + 36} />;
          })}
        </g>
      )}
    </g>
  );
};
