import React from 'react';
import {Audio, Sequence, staticFile} from 'remotion';
import {DURATION_FRAMES, FPS, sec, timing} from '../lib/timing';
import {skyAt} from '../lib/story';

/** Narasi (apa adanya) + musik lembut + hujan + SFX halus. */
export const AudioMix: React.FC = () => {
  const fadeIn = FPS * 2;
  const fadeOut = FPS * 3;
  return (
    <>
      <Audio src={staticFile('narasi.mp3')} volume={1} />
      <Audio
        src={staticFile('musik.wav')}
        loop
        volume={(f) => {
          const a = Math.min(1, f / fadeIn);
          const b = Math.min(1, (DURATION_FRAMES - f) / fadeOut);
          return 0.22 * Math.max(0, Math.min(a, b));
        }}
      />
      <Audio
        src={staticFile('sfx/hujan.wav')}
        loop
        volume={(f) => Math.max(0, skyAt(f / FPS).rain * 0.3)}
      />
      {timing.sfx.map((c, i) => {
        const base = timing.scenes.find((s) => s.id === c.scene);
        const at = (base?.start ?? 0) + c.offset;
        return (
          <Sequence key={i} from={sec(at)} durationInFrames={sec(4)}>
            <Audio src={staticFile(`sfx/${c.file}.wav`)} volume={c.volume * 0.7} />
          </Sequence>
        );
      })}
    </>
  );
};
