import React from 'react';
import {C, OUT_S, OUT_W} from '../lib/palette';
import {clockHands, laptopState, skyAt, T, E, WORLD} from '../lib/story';

const SY = WORLD.surfaceY;
const HL = WORLD.houseL;
const HR = WORLD.houseR;
const TOP = SY - WORLD.roomH;
const o = {stroke: C.outline, strokeWidth: OUT_W, strokeLinejoin: 'round' as const};
const os = {stroke: C.outline, strokeWidth: OUT_S, strokeLinejoin: 'round' as const};

const Frame: React.FC<{x: number; y: number; col: string}> = ({x, y, col}) => (
  <g transform={`translate(${x} ${y})`}>
    <circle cx={-16} cy={0} r={11} fill="#dff3ff" stroke={col} strokeWidth={5} />
    <circle cx={16} cy={0} r={11} fill="#dff3ff" stroke={col} strokeWidth={5} />
    <path d="M-5 -2 Q0 -6 5 -2" stroke={col} strokeWidth={4} fill="none" />
  </g>
);

const ChartRow: React.FC<{y: number; size: number; text: string}> = ({y, size, text}) => (
  <text x={0} y={y} textAnchor="middle" fontFamily="'DejaVu Sans', Verdana, sans-serif" fontWeight={800}
    fontSize={size} fill={C.outline} letterSpacing={size * 0.25}>{text}</text>
);

export const OptikBack: React.FC<{t: number}> = ({t}) => {
  const sky = skyAt(t);
  const hands = clockHands(t);
  const rad = (d: number) => (d * Math.PI) / 180;
  return (
    <g>
      {/* tanda toko di atap */}
      <rect x={760} y={TOP - 150} width={16} height={130} fill={C.woodDark} {...os} />
      <rect x={1020} y={TOP - 150} width={16} height={130} fill={C.woodDark} {...os} />
      <g transform={`translate(780 ${TOP - 190})`}>
        <rect x={-190} y={-40} width={420} height={150} rx={24} fill={C.optikSign} {...o} />
        <text x={20} y={58} textAnchor="middle" fontFamily="'DejaVu Sans', Verdana, sans-serif" fontWeight={800}
          fontSize={92} fill="#fff" stroke={C.outline} strokeWidth={5} paintOrder="stroke" letterSpacing={6}>OPTIK</text>
      </g>
      {/* dinding */}
      <rect x={HL} y={TOP} width={HR - HL} height={WORLD.roomH} fill={C.optikWall} {...o} />
      <rect x={HL} y={SY - 80} width={HR - HL} height={80} fill={C.optikWallShade} />
      <line x1={HL} y1={SY - 80} x2={HR} y2={SY - 80} stroke={C.outline} strokeWidth={OUT_S} />
      <rect x={HL - 24} y={TOP - 30} width={HR - HL + 48} height={34} fill={C.optikSign} {...o} />
      <rect x={HL - 20} y={SY - 14} width={HR - HL + 40} height={26} fill={C.optikFloor} {...o} />
      {/* rak bingkai kacamata */}
      <g>
        {[190, 300].map((y, i) => (
          <g key={y}>
            <rect x={90} y={TOP + y} width={240} height={12} fill={C.woodDark} {...os} />
            {[0, 1, 2].map((k) => (
              <Frame key={k} x={140 + k * 72} y={TOP + y - 16} col={['#c0502f', '#2f6f8f', '#e0b84a', '#3f8f3b'][(k + i * 2) % 4]} />
            ))}
          </g>
        ))}
      </g>
      {/* bagan huruf (pemeriksaan mata) */}
      <g transform={`translate(${WORLD.chartX} ${TOP + 70})`}>
        <rect x={-76} y={0} width={152} height={236} rx={8} fill="#fffdf5" {...o} />
        <ChartRow y={66} size={64} text="E" />
        <ChartRow y={112} size={40} text="FP" />
        <ChartRow y={150} size={28} text="TOZ" />
        <ChartRow y={182} size={20} text="LPED" />
        <ChartRow y={210} size={13} text="PECFD" />
      </g>
      {/* jam dinding: jarum dipercepat saat "lama menatap" */}
      <g transform={`translate(${WORLD.clockX} ${TOP + 120})`}>
        <circle r={58} fill="#fffdf5" {...o} />
        {Array.from({length: 12}, (_, i) => (
          <line key={i} x1={0} y1={-46} x2={0} y2={-52} stroke={C.outline} strokeWidth={4} transform={`rotate(${i * 30})`} />
        ))}
        <line x1={0} y1={0} x2={Math.cos(rad(hands.hour - 90)) * 28} y2={Math.sin(rad(hands.hour - 90)) * 28}
          stroke={C.outline} strokeWidth={8} strokeLinecap="round" />
        <line x1={0} y1={0} x2={Math.cos(rad(hands.minute - 90)) * 42} y2={Math.sin(rad(hands.minute - 90)) * 42}
          stroke={C.outline} strokeWidth={5} strokeLinecap="round" />
        <circle r={5} fill={C.outline} />
      </g>
      {/* jendela: warna langit ikut berubah; pohon jauh di luar */}
      <g transform={`translate(${WORLD.windowX} ${TOP + 70})`}>
        <rect x={-130} y={0} width={260} height={230} fill={sky.bottom} {...o} />
        <rect x={-130} y={0} width={260} height={230} fill={sky.top} opacity={0.6} />
        <rect x={-130} y={178} width={260} height={52} fill={C.grass} />
        <g transform="translate(40 178)">
          <rect x={-5} y={-40} width={10} height={40} fill={C.wood} {...os} />
          <circle cx={0} cy={-58} r={30} fill={C.grassDark} {...os} />
        </g>
        <line x1={0} y1={0} x2={0} y2={230} stroke={C.outline} strokeWidth={OUT_S + 1} />
        <line x1={-130} y1={115} x2={130} y2={115} stroke={C.outline} strokeWidth={OUT_S + 1} />
        <path d="M-112 22 L-60 22 L-112 74Z" fill="#fff" opacity={0.3} />
        <rect x={-130} y={0} width={260} height={230} fill="none" {...o} />
      </g>
      {/* meja layanan kiri */}
      <rect x={90} y={SY - 150} width={280} height={140} fill={C.wood} {...o} />
      <rect x={76} y={SY - 168} width={308} height={22} fill={C.woodDark} {...o} />
      {/* tanaman */}
      <g transform={`translate(1500 ${SY - 14})`}>
        <path d="M-30 0 L-24 -64 L24 -64 L30 0Z" fill={C.roof} {...o} />
        {[-40, 0, 40].map((x, i) => (
          <path key={i} d={`M0 -64 Q${x * 1.6} ${-150 - i * 14} ${x * 0.6} ${-190 + i * 10} Q${x * 0.2} ${-120} 0 -64Z`}
            fill={C.grass} {...os} />
        ))}
      </g>
      {/* kursi kerja Dani */}
      <rect x={676} y={SY - 340} width={34} height={230} rx={14} fill={C.chair} {...o} />
      <rect x={700} y={SY - 118} width={190} height={26} rx={12} fill={C.chair} {...o} />
      <rect x={780} y={SY - 94} width={18} height={70} fill={C.laptopShade} {...os} />
      <rect x={724} y={SY - 30} width={130} height={14} rx={7} fill={C.laptopShade} {...os} />
      {[732, 850].map((x) => <circle key={x} cx={x} cy={SY - 12} r={9} fill={C.outline} />)}
      {/* kursi periksa mata di kanan (properti toko) */}
      <g transform={`translate(1190 ${SY - 14})`} opacity={0}>
        <rect x={-40} y={-20} width={80} height={20} fill={C.chair} {...os} />
      </g>
    </g>
  );
};

/** Lapisan depan: meja, laptop (layar menyala), tumpukan buku, silau. */
export const OptikFront: React.FC<{t: number}> = ({t}) => {
  const L = laptopState(t);
  const deskY = WORLD.deskY;
  const stack = L.lift;
  const cx = L.x;
  const baseY = deskY - stack;
  const screenH = 150;
  const slider = t >= T('terang', 0.0) && t <= E('terang', 0.4);
  const knob = 40 + 80 * (L.bright - 0.4);
  const lum = 0.55 + 0.45 * L.bright;
  return (
    <g>
      {/* meja */}
      <rect x={880} y={deskY} width={470} height={24} rx={6} fill={C.desk} {...o} />
      <rect x={900} y={deskY + 24} width={20} height={SY - deskY - 38} fill={C.woodDark} {...o} />
      <rect x={1300} y={deskY + 24} width={20} height={SY - deskY - 38} fill={C.woodDark} {...o} />
      {/* tumpukan buku di bawah laptop (layar terlalu tinggi) */}
      {stack > 3 && (
        <g>
          <rect x={cx - 120} y={deskY - stack * 0.5} width={240} height={stack * 0.5} fill="#7a4a8a" {...os} />
          <rect x={cx - 130} y={deskY - stack} width={260} height={stack * 0.5} fill="#2f6f8f" {...os} />
        </g>
      )}
      {/* silau dari layar */}
      {L.glare > 0.02 && (
        <g opacity={Math.min(1, L.glare * 0.5)}>
          <defs>
            <radialGradient id="glareG" cx="0.5" cy="0.5" r="0.5">
              <stop offset="0" stopColor="#fffbe0" stopOpacity={0.9} />
              <stop offset="1" stopColor="#fffbe0" stopOpacity={0} />
            </radialGradient>
          </defs>
          <circle cx={cx} cy={baseY - screenH * 0.6} r={150 + 120 * L.glare} fill="url(#glareG)" />
          <path d={`M${cx - 115} ${baseY - screenH - 10} L${cx - 330} ${baseY - 330} L${cx - 330} ${baseY - 80} L${cx - 115} ${baseY - 40}Z`}
            fill="#fffbe0" opacity={0.28 * Math.min(1.4, L.glare)} />
        </g>
      )}
      {/* laptop */}
      <g>
        <path d={`M${cx - 130} ${baseY} L${cx + 130} ${baseY} L${cx + 118} ${baseY - 16} L${cx - 118} ${baseY - 16}Z`} fill={C.laptop} {...o} />
        <rect x={cx - 120} y={baseY - 16 - screenH} width={240} height={screenH} rx={10} fill={C.laptopShade} {...o} />
        <rect x={cx - 108} y={baseY - 16 - screenH + 10} width={216} height={screenH - 24} rx={4}
          fill={`rgb(${Math.round(207 * lum + 30)},${Math.round(238 * lum + 10)},${Math.round(255 * lum)})`} />
        <rect x={cx - 108} y={baseY - 16 - screenH + 10} width={216} height={18} fill="#4a8fd8" opacity={0.85} />
        {[0, 1, 2, 3].map((i) => (
          <rect key={i} x={cx - 96} y={baseY - 16 - screenH + 40 + i * 20} width={150 - i * 14} height={8} rx={4} fill={C.laptopShade} opacity={0.5} />
        ))}
        <rect x={cx + 36} y={baseY - 16 - screenH + 44} width={56} height={46} rx={4} fill={C.apple} opacity={0.75} />
        {slider && (
          <g transform={`translate(${cx} ${baseY - 16 - screenH * 0.5})`}>
            <rect x={-80} y={-26} width={160} height={52} rx={12} fill="#fffdf5" {...os} />
            <circle cx={-58} cy={0} r={9} fill="#ffd54f" stroke={C.outline} strokeWidth={3} />
            <rect x={-38} y={-4} width={104} height={8} rx={4} fill="#c9c2b0" />
            <rect x={-38} y={-4} width={knob * 0.8} height={8} rx={4} fill="#4a8fd8" />
            <circle cx={-38 + knob * 0.8} cy={0} r={9} fill="#fff" stroke={C.outline} strokeWidth={4} />
          </g>
        )}
      </g>
    </g>
  );
};

