import React from 'react';
import {C, OUT_S, OUT_W} from '../lib/palette';
import type {MState} from '../lib/story';

const RX = 78;
const RY = 70;
const lw = {stroke: C.outline, strokeWidth: 6, strokeLinecap: 'round' as const, fill: 'none'};

const veins = [
  'M-74 -10 Q-52 -14 -34 -4',
  'M-70 24 Q-50 20 -36 14',
  'M-40 -58 Q-34 -40 -26 -30',
  'M70 -14 Q52 -12 38 -6',
  'M66 26 Q50 22 38 16',
  'M30 58 Q26 44 22 34',
  'M-28 60 Q-26 46 -22 36',
];

const cracksP = [
  'M-60 -30 L-40 -10 L-52 6 L-30 26 L-44 44',
  'M58 -34 L40 -14 L54 4 L34 22',
  'M-6 -64 L4 -44 L-8 -30 L6 -14',
];

const star = (cx: number, cy: number, r: number) =>
  `M${cx} ${cy - r} L${cx + r * 0.3} ${cy - r * 0.3} L${cx + r} ${cy} L${cx + r * 0.3} ${cy + r * 0.3} L${cx} ${cy + r} L${cx - r * 0.3} ${cy + r * 0.3} L${cx - r} ${cy} L${cx - r * 0.3} ${cy - r * 0.3}Z`;

export const Mimi: React.FC<{s: MState; t: number}> = ({s, t}) => {
  const lidBase = s.expr === 'sedih' ? 0.28 : s.expr === 'tekad' ? 0.18 : s.expr === 'senang' ? 0.12 : 0;
  const lid = Math.max(s.blink, lidBase);
  const ix = s.lookX * 24;
  const iy = s.lookY * 18;
  const pr = s.expr === 'kaget' ? 9 : 14;
  const wob = s.strain * Math.sin(t * 40) * 2.2;

  const brow =
    s.expr === 'sedih' ? 'M-52 -96 L-10 -108 M10 -108 L52 -96'
    : s.expr === 'kaget' ? 'M-52 -112 Q-30 -126 -8 -112 M8 -112 Q30 -126 52 -112'
    : s.expr === 'tekad' ? 'M-54 -112 L-8 -96 M8 -96 L54 -112'
    : 'M-52 -104 Q-30 -116 -8 -104 M8 -104 Q30 -116 52 -104';
  const mouth =
    s.expr === 'sedih' ? 'M-18 124 Q0 112 18 124'
    : s.expr === 'senang' ? 'M-22 114 Q0 134 22 114'
    : s.expr === 'kaget' ? ''
    : 'M-16 118 L16 118';

  return (
    <g transform={`translate(${s.x} ${s.y}) scale(${s.scale})`}>
      <defs>
        <clipPath id="mimiClip">
          <ellipse cx={0} cy={0} rx={RX} ry={RY} />
        </clipPath>
      </defs>

      {/* pita otot mata (menegang saat fokus dekat) */}
      {s.strain > 0.02 && (
        <g opacity={s.strain}>
          {[[-150, -70], [150, -70], [-150, 70], [150, 70]].map(([ax, ay], i) => (
            <g key={i}>
              <path d={`M${ax * (1 + 0.1 * s.strain)} ${ay + wob} L${ax * 0.5} ${ay * 0.62}`} stroke={C.outline} strokeWidth={22} strokeLinecap="round" />
              <path d={`M${ax * (1 + 0.1 * s.strain)} ${ay + wob} L${ax * 0.5} ${ay * 0.62}`} stroke="#f08a8a" strokeWidth={13} strokeLinecap="round" />
              <circle cx={ax * (1 + 0.1 * s.strain)} cy={ay + wob} r={11} fill={C.skinShade} stroke={C.outline} strokeWidth={OUT_S} />
            </g>
          ))}
        </g>
      )}

      {/* bola mata */}
      <ellipse cx={0} cy={0} rx={RX} ry={RY} fill={C.sclera} stroke={C.outline} strokeWidth={OUT_W + 1} />
      <g clipPath="url(#mimiClip)">
        <path d="M30 -70 Q82 -30 62 40 Q40 74 0 72 Q56 38 30 -70Z" fill={C.scleraShade} opacity={0.8} />
        {veins.map((d, i) => (
          <path key={i} d={d} stroke={C.vein} strokeWidth={3.4} fill="none" strokeLinecap="round" opacity={s.redness} />
        ))}
        {/* iris */}
        <g transform={`translate(${ix} ${iy})`}>
          <circle r={34} fill={C.iris} stroke={C.outline} strokeWidth={OUT_S + 1} />
          <path d="M-24 8 Q0 36 24 8 Q8 28 -24 8Z" fill={C.irisDark} opacity={0.8} />
          <circle r={pr} fill={C.outline} />
          <circle cx={-10} cy={-12} r={7} fill="#fff" />
          <circle cx={9} cy={8} r={3.5} fill="#fff" opacity={0.85} />
        </g>
        {/* retakan karena kering */}
        {s.cracks > 0.01 &&
          cracksP.map((d, i) => (
            <path key={i} d={d} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - Math.min(1, s.cracks * 1.2 - i * 0.1)}
              stroke={C.crack} strokeWidth={4.5} fill="none" strokeLinecap="round" strokeLinejoin="round" />
          ))}
        {/* lapisan air */}
        <ellipse cx={0} cy={0} rx={RX} ry={RY} fill={C.water} opacity={0.3 * s.film} />
        <path d="M-56 -34 Q-44 -52 -22 -56" stroke="#fff" strokeWidth={6} strokeLinecap="round" fill="none" opacity={0.85 * s.film} />
        {/* kelopak atas */}
        <path
          d={`M${-RX - 6} ${-RY - 8} L${RX + 6} ${-RY - 8} L${RX + 6} ${-RY - 8 + lid * 2 * RY} Q0 ${-RY - 8 + lid * 2 * RY + 26 * (1 - lid * 0.6)} ${-RX - 6} ${-RY - 8 + lid * 2 * RY}Z`}
          fill={C.skin} stroke={C.outline} strokeWidth={OUT_W} strokeLinejoin="round"
        />
      </g>
      <ellipse cx={0} cy={0} rx={RX} ry={RY} fill="none" stroke={C.outline} strokeWidth={OUT_W + 1} />

      {/* tetes air di tepi bawah (lapisan air cukup) */}
      {s.film > 0.55 && (
        <path d="M-30 66 Q-26 84 -20 90 Q-12 80 -14 68Z" fill={C.waterLight} stroke={C.outline} strokeWidth={OUT_S - 1} opacity={s.film} />
      )}

      {/* alis & mulut: wajah minimalis (garis) */}
      <path d={brow} stroke={C.outline} strokeWidth={13} strokeLinecap="round" fill="none" />
      <path d={brow} stroke={C.hairBlack} strokeWidth={7} strokeLinecap="round" fill="none" />
      {s.expr === 'kaget' ? (
        <ellipse cx={0} cy={118} rx={13} ry={17} fill={C.outline} />
      ) : (
        <path d={mouth} {...lw} />
      )}

      {/* berkunang-kunang */}
      {s.floaters > 0.01 &&
        [0, 1, 2, 3, 4].map((i) => {
          const a = t * 2.2 + (i * Math.PI * 2) / 5;
          return (
            <path key={i} d={star(Math.cos(a) * (120 + i * 6), Math.sin(a) * 92 - 20, 15 + (i % 2) * 5)}
              fill="#ffe27a" stroke={C.outline} strokeWidth={OUT_S - 1} strokeLinejoin="round" opacity={s.floaters} />
          );
        })}

      {/* kilau segar saat berkedip sengaja */}
      {s.sparkle > 0.01 &&
        [0, 1, 2, 3].map((i) => {
          const a = (i / 4) * Math.PI * 2 + 0.6;
          const r = 11 + 5 * Math.sin(t * 7 + i * 1.7);
          return (
            <path key={i} d={star(Math.cos(a) * 112, Math.sin(a) * 96, r)}
              fill="#fff7b0" stroke={C.outline} strokeWidth={OUT_S - 1} strokeLinejoin="round" opacity={s.sparkle} />
          );
        })}
    </g>
  );
};
