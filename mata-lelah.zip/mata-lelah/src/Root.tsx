import React from 'react';
import {Composition} from 'remotion';
import {MataLelah} from './MataLelah';
import {DURATION_FRAMES, FPS, HEIGHT, WIDTH} from './lib/timing';

export const RemotionRoot: React.FC = () => (
  <Composition
    id="MataLelah"
    component={MataLelah}
    durationInFrames={DURATION_FRAMES}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
  />
);
