import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {AudioMix} from './components/AudioMix';
import {Dani} from './components/Dani';
import {Hud} from './components/Hud';
import {Mimi} from './components/Mimi';
import {OptikBack, OptikFront} from './components/Optik';
import {Sky} from './components/Sky';
import {Subtitles} from './components/Subtitles';
import {World} from './components/World';
import {C} from './lib/palette';
import {blink, camera, daniPose, mimiState, skyAt, T, WORLD} from './lib/story';
import {DURATION_FRAMES, FPS, HEIGHT, WIDTH, prog} from './lib/timing';

export const MataLelah: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;

  const cam = camera(t);
  const sway = Math.sin(t * 0.8) * 3;
  const tx = WIDTH / 2 - cam.cx * cam.s + sway;
  const ty = HEIGHT / 2 - cam.cy * cam.s;

  const sky = skyAt(t);
  const nightA = sky.stars * 0.34;
  const goldA = prog(t, T('istirahat'), T('istirahat', 3)) * 0.1;
  const fadeOut = Math.min(1, Math.max(0, (DURATION_FRAMES / FPS - t) / 0.7));
  const fadeInA = Math.min(1, t / 0.4);
  const W = WORLD;

  return (
    <AbsoluteFill style={{backgroundColor: C.skyTop}}>
      <AbsoluteFill>
        <svg width={WIDTH} height={HEIGHT} viewBox={`0 0 ${WIDTH} ${HEIGHT}`}>
          <g transform={`translate(${tx} ${ty}) scale(${cam.s})`}>
            <Sky t={t} />
            <World t={t} />
            <OptikBack t={t} />
            <Dani pose={daniPose(t)} blink={blink(t)} x={W.chairX} floor={W.surfaceY - 14} />
            <OptikFront t={t} />
            <Mimi s={mimiState(t)} t={t} />
            <rect x={W.left} y={W.top} width={W.right - W.left} height={W.bottom - W.top}
              fill="#0a1030" opacity={nightA} pointerEvents="none" />
            <rect x={W.left} y={W.top} width={W.right - W.left} height={W.bottom - W.top}
              fill="#ff9a3c" opacity={goldA} pointerEvents="none" />
          </g>
        </svg>
      </AbsoluteFill>
      <Hud t={t} />
      <Subtitles t={t} />
      <AbsoluteFill style={{background: '#0d0a08', opacity: 1 - Math.min(fadeOut, fadeInA), pointerEvents: 'none'}} />
      <AudioMix />
    </AbsoluteFill>
  );
};
