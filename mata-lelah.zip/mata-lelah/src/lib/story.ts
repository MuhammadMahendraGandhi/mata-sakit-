import {ease, lerp, prog, sceneByKey, timing} from './timing';
import type {Expression, SkyKey} from './types';
import {mix} from './color';

/** Mulai / akhir adegan (detik) dari timing.json, + offset opsional. */
export const T = (key: string, off = 0): number => (sceneByKey(key)?.start ?? 0) + off;
export const E = (key: string, off = 0): number => (sceneByKey(key)?.end ?? 0) + off;

// ---------------------------------------------------------------- dunia
export const WORLD = {
  surfaceY: 1300,
  left: -500,
  right: 2700,
  bottom: 3600,
  top: -900,
  houseL: 40,
  houseR: 1560,
  roomH: 620,
  chairX: 770,
  laptopX: 980,
  deskY: 1300 - 190,
  windowX: 1340,
  clockX: 640,
  chartX: 400,
  treeX: 2250,
  mimiX: 640,
  mimiY: 880,
};

const clamp01 = (x: number) => Math.min(1, Math.max(0, x));

// ---------------------------------------------------------------- kamera
export type Cam = {cx: number; cy: number; s: number};
type CamKey = {t: number} & Cam;

const camKeys = (): CamKey[] => [
  {t: 0, cx: 900, cy: 1100, s: 1.2},
  {t: T('perih', 0.3), cx: 900, cy: 1100, s: 1.2},
  {t: T('perih', 1.4), cx: 710, cy: 930, s: 2.0},
  {t: E('perih', 0.2), cx: 710, cy: 930, s: 2.0},
  {t: T('lama', 0.4), cx: 950, cy: 1100, s: 1.2},
  {t: T('jarang', 0.3), cx: 700, cy: 910, s: 2.2},
  {t: T('kering', 0.7), cx: 700, cy: 910, s: 2.2},
  {t: T('kering', 1.6), cx: 800, cy: 1850, s: 0.9},
  {t: E('kering', 0.1), cx: 800, cy: 1850, s: 0.9},
  {t: T('otot', 0.9), cx: 700, cy: 910, s: 2.2},
  {t: T('silau', 0.2), cx: 950, cy: 1050, s: 1.3},
  {t: T('letih', 0.3), cx: 720, cy: 930, s: 2.0},
  {t: T('letih', 3.4), cx: 720, cy: 930, s: 2.0},
  {t: T('aturan', 0.2), cx: 900, cy: 1000, s: 1.2},
  {t: T('enam', 0.2), cx: 1100, cy: 1100, s: 1.15},
  {t: T('kedip', 0.2), cx: 700, cy: 910, s: 2.2},
  {t: T('kedip', 1.9), cx: 700, cy: 910, s: 2.2},
  {t: T('lengan', 0.1), cx: 950, cy: 1100, s: 1.25},
  {t: T('posisi', 0.1), cx: 900, cy: 1050, s: 1.4},
  {t: T('terang', 0.1), cx: 1000, cy: 1050, s: 1.5},
  {t: E('terang', -0.2), cx: 1000, cy: 1050, s: 1.5},
  {t: T('istirahat', 1.0), cx: 900, cy: 1100, s: 1.15},
  {t: E('istirahat', 0.4), cx: 800, cy: 1500, s: 0.55},
  {t: 999, cx: 800, cy: 1500, s: 0.55},
];

export const camera = (t: number): Cam => {
  const k = camKeys();
  for (let i = 0; i < k.length - 1; i++) {
    if (t >= k[i].t && t < k[i + 1].t) {
      const x = ease((t - k[i].t) / Math.max(0.001, k[i + 1].t - k[i].t));
      return {
        cx: lerp(k[i].cx, k[i + 1].cx, x),
        cy: lerp(k[i].cy, k[i + 1].cy, x),
        s: lerp(k[i].s, k[i + 1].s, x),
      };
    }
  }
  return k[0];
};

// ---------------------------------------------------------------- kedipan
/** Denyut berkedip (0..1) dari daftar waktu. */
const pulse = (t: number, times: number[], dur = 0.2): number => {
  let v = 0;
  for (const a of times) {
    const d = (t - a) / dur;
    if (d >= 0 && d <= 1) v = Math.max(v, Math.sin(d * Math.PI));
  }
  return v;
};

const blinkTimes = (): number[] => [
  2.2, 6.0, 9.2, 12.4,
  T('kedip', 0.3), T('kedip', 1.0), T('kedip', 1.7), T('kedip', 2.2),
  T('lengan', 1.3), T('posisi', 0.6), T('terang', 1.0),
];

/** Kedip alami: tertutup 0..1 (dipakai Dani dan Mimi). */
export const blink = (t: number): number => {
  if (t >= T('istirahat', 0.5) && t <= E('istirahat', -0.2)) return 1;
  return pulse(t, blinkTimes());
};

/** Angka kedipan per menit untuk HUD. */
export const blinkRate = (t: number): number => {
  const a = T('jarang', 0.2);
  const b = E('fokus', 0);
  if (t < a) return 15;
  if (t < b) return Math.round(lerp(15, 5, ease(prog(t, a, b))));
  if (t < T('kedip')) return 5;
  return Math.round(lerp(5, 15, ease(prog(t, T('kedip'), E('kedip', 0.4)))));
};

// ---------------------------------------------------------------- Dani
export type DPose = {
  armL: number;
  armR: number;
  lean: number; // derajat, positif = condong ke depan (ke layar)
  neck: number; // kepala menjulur ke depan (px)
  tilt: number;
  mouth: number;
  expr: Expression;
  phone: number; // 1 = memegang HP
};

const dBase: DPose = {armL: -60, armR: -70, lean: 12, neck: 14, tilt: 0, mouth: 0, expr: 'senang', phone: 0};

type DKey = {t: number} & Partial<DPose>;

const daniKeys = (): DKey[] => [
  {t: 0, expr: 'senang', lean: 10, neck: 12},
  {t: T('perih', 1.0), expr: 'senang'},
  {t: T('perih', 1.3), expr: 'sedih', armR: -70},
  {t: T('perih', 1.9), expr: 'sedih', armR: -165, tilt: -4},
  {t: T('perih', 3.0), armR: -165, expr: 'sedih'},
  {t: E('perih', 0.3), armR: -70, expr: 'sedih', tilt: 0},
  // lama menatap: makin dekat ke layar, lalu pegang HP
  {t: T('lama'), expr: 'sedih', lean: 14, neck: 16},
  {t: T('lama', 2.6), lean: 20, neck: 24},
  {t: T('lama', 3.2), armR: -100, phone: 1, lean: 22, neck: 26, tilt: 8},
  {t: E('lama', -0.4), armR: -100, phone: 1, lean: 26, neck: 30, tilt: 10},
  // jarang berkedip: menatap lurus
  {t: T('jarang'), expr: 'kaget', phone: 0, armR: -70, lean: 22, neck: 28, tilt: 0},
  {t: T('kering'), expr: 'sedih'},
  {t: T('otot'), expr: 'tekad', lean: 26, neck: 34},
  {t: T('silau'), expr: 'kaget', lean: 22, neck: 28},
  {t: T('silau', 1.1), expr: 'kaget', armR: -150, armL: -60},
  {t: E('silau', -0.2), expr: 'sedih', armR: -150},
  {t: T('letih'), expr: 'sedih', armR: -70, lean: 28, neck: 32, tilt: 10},
  {t: T('letih', 3.0), expr: 'sedih', lean: 30, tilt: 14},
  {t: T('letih', 3.7), expr: 'kaget', lean: 6, neck: 6, tilt: 0, mouth: 0.6},
  // solusi
  {t: T('aturan', 0.2), expr: 'tekad', lean: 2, neck: 0, mouth: 0, armR: -25, armL: -10},
  {t: T('aturan', 2.6), expr: 'senang'},
  {t: T('enam'), expr: 'tekad', tilt: 6, armR: -25, armL: -10},
  {t: T('enam', 1.5), expr: 'tekad', tilt: -4},
  {t: T('kedip'), expr: 'senang', tilt: 0},
  {t: T('lengan'), expr: 'tekad', lean: -4, neck: 0, armR: -92, armL: -60},
  {t: T('lengan', 2.4), expr: 'senang', armR: -92},
  {t: T('posisi'), expr: 'senang', lean: 4, tilt: 8, armR: -70},
  {t: T('terang'), expr: 'senang', lean: 2, tilt: 0, armR: -84},
  {t: T('terang', 2.8), expr: 'senang', armR: -84},
  {t: T('istirahat', 0.3), expr: 'senang', lean: -10, neck: -4, armR: -175, armL: 175, mouth: 0.2},
  {t: 999, expr: 'senang', lean: -10, neck: -4, armR: -175, armL: 175, mouth: 0.2},
];

const dNum: (keyof DPose)[] = ['armL', 'armR', 'lean', 'neck', 'tilt', 'mouth', 'phone'];

const dFilled = (): ({t: number} & DPose)[] => {
  const out: ({t: number} & DPose)[] = [];
  let cur: DPose = {...dBase};
  for (const k of daniKeys()) {
    cur = {...cur, ...k};
    out.push({...cur, t: k.t});
  }
  return out;
};

export const daniPose = (t: number): DPose => {
  const k = dFilled();
  for (let i = 0; i < k.length - 1; i++) {
    if (t >= k[i].t && t < k[i + 1].t) {
      const x = ease((t - k[i].t) / Math.max(0.001, k[i + 1].t - k[i].t));
      const p = {...k[i]} as DPose;
      const rec = p as unknown as Record<string, number>;
      for (const f of dNum) rec[f] = lerp(k[i][f] as number, k[i + 1][f] as number, x);
      return p;
    }
  }
  return {...k[k.length - 1]} as DPose;
};

// ---------------------------------------------------------------- Mimi (mata)
export type MState = {
  x: number;
  y: number;
  scale: number;
  expr: Expression;
  blink: number;
  film: number; // lapisan air 0..1
  redness: number;
  cracks: number; // 0..1 retak di bola mata
  strain: number; // 0..1 otot menegang
  floaters: number; // bintang berkunang-kunang
  sparkle: number;
  lookX: number;
  lookY: number;
};

export const mimiState = (t: number): MState => {
  const bob = Math.sin(t * 2.1) * 6;
  const expr: Expression =
    t < T('jarang') ? 'sedih'
    : t < T('air') ? 'kaget'
    : t < T('otot') ? 'sedih'
    : t < T('silau') ? 'tekad'
    : t < T('aturan') ? 'sedih'
    : t < T('kedip') ? 'tekad'
    : 'senang';

  const film =
    t < T('fokus') ? 1
    : t < E('air', -0.4) ? lerp(1, 0.12, ease(prog(t, T('fokus'), E('air', -0.4))))
    : t < T('kedip') ? 0.12
    : lerp(0.12, 1, ease(prog(t, T('kedip'), E('kedip', 3.2))));

  const redness =
    t < T('perih', 1.2) ? lerp(0.15, 0.6, prog(t, 0, T('perih', 1.2)))
    : t < T('kedip') ? Math.min(0.9, 0.6 + 0.3 * prog(t, T('kering'), T('letih')))
    : lerp(0.9, 0.05, ease(prog(t, T('kedip'), E('terang'))));

  const cracks = t < T('kering') ? 0 : t < T('kedip') ? ease(prog(t, T('kering'), T('kering', 2.4))) : 1 - ease(prog(t, T('kedip'), T('kedip', 2.4)));

  const strain =
    t < T('otot') ? 0
    : t < T('letih') ? ease(prog(t, T('otot'), T('otot', 2.2)))
    : t < T('aturan') ? 0.6
    : 1 - ease(prog(t, T('aturan'), T('aturan', 1.5)));

  const floaters = t < E('perih', 0.3) ? clamp01(prog(t, 0.5, 1.2)) : 0;
  const sparkle = t >= T('kedip') && t < E('kedip', 1.5) ? 1 : t >= T('istirahat') ? 0.7 : 0;

  // arah pandang: ke layar (kanan-bawah), ke jendela saat "enam meter", sisanya acak halus
  let lookX = 0.8;
  let lookY = 0.1;
  if (t >= T('enam') && t < T('kedip')) { lookX = 0.9; lookY = -0.5; }
  if (t >= T('kedip')) { lookX = Math.sin(t * 1.3) * 0.4; lookY = Math.cos(t * 1.1) * 0.2; }

  return {
    x: WORLD.mimiX,
    y: WORLD.mimiY + bob,
    scale: 1,
    expr,
    blink: blink(t),
    film, redness, cracks, strain, floaters, sparkle, lookX, lookY,
  };
};

// ---------------------------------------------------------------- laptop & jam
export type LState = {x: number; lift: number; bright: number; glare: number};

export const laptopState = (t: number): LState => {
  const x = WORLD.laptopX + 90 * ease(prog(t, T('lengan', 0.1), T('lengan', 1.4)));
  const lift = 110 * (1 - ease(prog(t, T('posisi', 0.1), T('posisi', 1.2))));
  const bright =
    t < T('terang', 0.4) ? 1 : lerp(1, 0.5, ease(prog(t, T('terang', 0.5), T('terang', 2.4))));
  const night = t > T('lama', 3.5) && t < T('aturan') ? 1 : 0.45;
  let glare = bright * night * 0.55;
  if (t >= T('silau') && t < T('letih')) glare = 1.1 + 0.2 * Math.sin(t * 6);
  if (t >= T('letih') && t < T('aturan')) glare = 0.8;
  if (t >= T('aturan') && t < T('terang')) glare = 0.5;
  if (t >= T('terang')) glare = lerp(0.5, 0.05, ease(prog(t, T('terang', 0.5), T('terang', 2.4))));
  return {x, lift, bright, glare};
};

/** Sudut jarum jam (derajat): jam 9 pagi -> 9 malam dipercepat di adegan "lama". */
export const clockHands = (t: number): {hour: number; minute: number} => {
  const run = ease(prog(t, T('lama', 0.2), E('lama', -0.6)));
  const hour = 270 + run * 360;
  return {hour, minute: (hour * 12) % 360};
};

/** Permukaan air tanah (y dunia): turun saat mata kering, naik saat berkedip sengaja. */
export const wetLevel = (t: number): number => {
  if (t < T('fokus')) return 1720;
  if (t < E('kering')) return lerp(1720, 2550, ease(prog(t, T('fokus'), E('kering'))));
  if (t < T('kedip')) return 2550;
  return lerp(2550, 1720, ease(prog(t, T('kedip'), E('istirahat'))));
};

/** Retak tanah memudar saat air kembali. */
export const crackFade = (t: number): number => 1 - ease(prog(t, T('kedip', 0.5), E('lengan')));

// ---------------------------------------------------------------- HUD info
export type HudKind = 'kedip' | 'aturan' | 'enam' | 'lengan' | 'posisi' | 'jam' | null;
export type Hud = {kind: HudKind; p: number; a: number};

export const hud = (t: number): Hud => {
  const spans: [HudKind, number, number][] = [
    ['kedip', T('jarang', 0.2), E('fokus', 0.1)],
    ['jam', T('lama', 0.1), E('lama', -0.2)],
    ['aturan', T('aturan', 0.1), E('aturan', 0)],
    ['enam', T('enam', 0.1), E('enam', 0)],
    ['kedip', T('kedip', 0.0), E('kedip', 0.2)],
    ['lengan', T('lengan', 0.0), E('lengan', 0)],
    ['posisi', T('posisi', 0.0), E('posisi', 0)],
  ];
  for (const [k, a, b] of spans) {
    if (t >= a && t <= b) {
      const fi = clamp01((t - a) / 0.25);
      const fo = clamp01((b - t) / 0.25);
      return {kind: k, p: prog(t, a, b), a: Math.min(fi, fo)};
    }
  }
  return {kind: null, p: 0, a: 0};
};

// ---------------------------------------------------------------- langit
export type SkyNow = {top: string; bottom: string; stars: number; sun: number; cloud: number; rain: number};

export const skyAt = (t: number): SkyNow => {
  const k: SkyKey[] = timing.sky;
  let i = 0;
  while (i < k.length - 1 && t >= k[i + 1].t) i++;
  const a = k[i];
  const b = k[Math.min(i + 1, k.length - 1)];
  const x = b.t === a.t ? 0 : ease(clamp01((t - a.t) / (b.t - a.t)));
  return {
    top: mix(a.top, b.top, x),
    bottom: mix(a.bottom, b.bottom, x),
    stars: lerp(a.stars, b.stars, x),
    sun: lerp(a.sun, b.sun, x),
    cloud: lerp(a.cloud, b.cloud, x),
    rain: lerp(a.rain, b.rain, x),
  };
};
